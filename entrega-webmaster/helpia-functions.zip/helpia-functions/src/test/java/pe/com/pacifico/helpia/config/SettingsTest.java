package pe.com.pacifico.helpia.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import pe.com.pacifico.helpia.common.ApiException;
import pe.com.pacifico.helpia.common.Env;
import pe.com.pacifico.helpia.common.ErrorCatalog;
import pe.com.pacifico.helpia.infrastructure.local.LocalMode;

class SettingsTest {

    @Test
    void given_bypassLocalEnAzure_when_load_then_bloqueado() {
        Env env = env(Map.of("JWT_LOCAL_BYPASS", "true", "WEBSITE_SITE_NAME", "funchpiaeu2p01"));

        ApiException e = assertThrows(ApiException.class, () -> JwtSettings.load(env));
        assertEquals(ErrorCatalog.INSECURE_CONFIGURATION_BLOCKED, e.error());
    }

    @Test
    void given_configuracionJwtIncompleta_when_load_then_configurationError() {
        Env env = env(Map.of("JWT_TENANT_ID", "11111111-1111-1111-1111-111111111111"));

        ApiException e = assertThrows(ApiException.class, () -> JwtSettings.load(env));
        assertEquals(ErrorCatalog.JWT_CONFIGURATION_ERROR, e.error());
    }

    /** En Python una lista vacía aceptaba cualquier dominio. */
    @Test
    void given_dominiosVacios_when_load_then_fallaCerrado() {
        ApiException e = assertThrows(ApiException.class,
                () -> EmailDomainSettings.load(env(Map.of("ALLOWED_EMAIL_DOMAINS", " , "))));
        assertEquals(ErrorCatalog.CONFIGURATION_ERROR, e.error());
    }

    @Test
    void given_secretoCorto_when_loadCallback_then_configurationError() {
        Env env = env(Map.of("CALLBACK_BASE_URL", "https://bot.example.com", "CALLBACK_HMAC_SECRET", "corto"));

        assertThrows(ApiException.class, () -> CallbackSettings.load(env));
    }

    @Test
    void given_callbackHttpEnAzure_when_load_then_configurationError() {
        Env azure = env(Map.of("WEBSITE_SITE_NAME", "x", "CALLBACK_BASE_URL", "http://localhost:9999",
                "CALLBACK_HMAC_SECRET", "secreto-local-solo-para-docker-0123456789"));

        assertThrows(ApiException.class, () -> CallbackSettings.load(azure));
    }

    @Test
    void given_localModeEnAzure_when_isEnabled_then_falso() {
        Env azure = env(Map.of("LOCAL_MODE", "true", "WEBSITE_INSTANCE_ID", "abc"));
        Env local = env(Map.of("LOCAL_MODE", "true"));

        assertEquals(false, LocalMode.isEnabled(azure));
        assertEquals(true, LocalMode.isEnabled(local));
    }

    private static Env env(Map<String, String> values) {
        Map<String, String> copy = new HashMap<>(values);
        return new Env(copy::get);
    }
}
