package pe.com.pacifico.helpia.infrastructure.local;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Map;
import org.junit.jupiter.api.Test;
import pe.com.pacifico.helpia.infrastructure.automation.AutomationException;

class LocalRunbookGatewayTest {

    private static final Map<String, String> PARAMS = Map.of("CorrelationId", "c1", "Operacion", "RESETEO", "Usuario", "mjperez");

    @Test
    void given_jobCreado_when_pasaLaDuracion_then_running_y_luego_completed() {
        MutableClock clock = new MutableClock(Instant.parse("2026-10-14T15:00:00Z"));
        LocalRunbookGateway gateway = new LocalRunbookGateway(clock, Duration.ofSeconds(10));
        gateway.createJob("j1", "RB", PARAMS);

        assertEquals("Running", gateway.getJobStatus("j1"));
        clock.advance(Duration.ofSeconds(10));
        assertEquals("Completed", gateway.getJobStatus("j1"));
        assertTrue(gateway.getJobOutput("j1").contains("\"codigo\":\"RESETEADO\""));
    }

    @Test
    void given_usuarioRapido_when_pasa1Segundo_then_completed() {
        MutableClock clock = new MutableClock(Instant.parse("2026-10-14T15:00:00Z"));
        LocalRunbookGateway gateway = new LocalRunbookGateway(clock, Duration.ofSeconds(10));
        gateway.createJob("j2", "RB", Map.of("CorrelationId", "c2", "Operacion", "DESBLOQUEO", "Usuario", "rapido"));

        clock.advance(Duration.ofSeconds(1));
        assertEquals("Completed", gateway.getJobStatus("j2"));
    }

    @Test
    void given_jobInexistente_when_consulta_then_automationException() {
        LocalRunbookGateway gateway = new LocalRunbookGateway(Clock.systemUTC(), Duration.ofSeconds(10));

        assertThrows(AutomationException.class, () -> gateway.getJobStatus("no-existe"));
    }

    static final class MutableClock extends Clock {
        private Instant now;

        MutableClock(Instant start) {
            this.now = start;
        }

        void advance(Duration d) {
            now = now.plus(d);
        }

        @Override
        public ZoneId getZone() {
            return ZoneOffset.UTC;
        }

        @Override
        public Clock withZone(ZoneId zone) {
            return this;
        }

        @Override
        public Instant instant() {
            return now;
        }
    }
}
