package pe.com.pacifico.helpia.infrastructure.local;

import pe.com.pacifico.helpia.common.Env;

/**
 * LOCAL_MODE=true reemplaza Graph, Automation y el callback por implementaciones en memoria,
 * para probar solo el core: endpoints + Durable Functions + Task hub (Azurite).
 * Nunca se activa en Azure, aunque el setting exista.
 */
public final class LocalMode {

    private LocalMode() {
    }

    public static boolean isEnabled(Env env) {
        return env.isTrue("LOCAL_MODE") && !env.isRunningInAzure();
    }
}
