package pe.com.pacifico.helpia.config;

import java.util.Set;
import java.util.regex.Pattern;
import pe.com.pacifico.helpia.common.ApiException;
import pe.com.pacifico.helpia.common.Env;
import pe.com.pacifico.helpia.common.ErrorCatalog;

/** Configuración de validación JWT. Equivale a _load_jwt_configuration() de Python. */
public record JwtSettings(
        String tenantId,
        Set<String> audiences,
        Set<String> allowedClientIds,
        String requiredPermission,
        boolean localBypass) {

    public static final String DEFAULT_REQUIRED_PERMISSION = "EmailValidation.Read";
    private static final Pattern GUID = Pattern.compile(
            "^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", Pattern.CASE_INSENSITIVE);

    /**
     * Carga y valida. Lanza ApiException con los mismos códigos que Python cuando la configuración
     * es incompleta (503 JWT_CONFIGURATION_ERROR) o insegura (503 INSECURE_CONFIGURATION_BLOCKED).
     */
    public static JwtSettings load(Env env) {
        boolean bypass = env.isTrue("JWT_LOCAL_BYPASS");
        if (bypass && (env.isRunningInAzure() || !"local".equalsIgnoreCase(env.get("APP_ENV", "local")))) {
            throw new ApiException(ErrorCatalog.INSECURE_CONFIGURATION_BLOCKED);
        }

        String tenantId = env.get("JWT_TENANT_ID").toLowerCase();
        Set<String> audiences = env.getList("JWT_ALLOWED_AUDIENCES", false);
        Set<String> clientIds = env.getList("JWT_ALLOWED_CLIENT_IDS", true);
        String permission = env.get("JWT_REQUIRED_PERMISSION", DEFAULT_REQUIRED_PERMISSION);

        boolean validClientIds = !clientIds.isEmpty() && clientIds.stream().allMatch(id -> GUID.matcher(id).matches());
        if (!bypass && (!GUID.matcher(tenantId).matches() || audiences.isEmpty() || !validClientIds || permission.isEmpty())) {
            throw new ApiException(ErrorCatalog.JWT_CONFIGURATION_ERROR);
        }
        return new JwtSettings(tenantId, audiences, clientIds, permission, bypass);
    }

    public Set<String> validIssuers() {
        return Set.of(
                "https://login.microsoftonline.com/" + tenantId + "/v2.0",
                "https://sts.windows.net/" + tenantId + "/");
    }

    public String jwksUrl() {
        return "https://login.microsoftonline.com/" + tenantId + "/discovery/v2.0/keys";
    }
}
