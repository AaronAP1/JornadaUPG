package pe.com.pacifico.helpia.config;

import pe.com.pacifico.helpia.common.ApiException;
import pe.com.pacifico.helpia.common.Env;
import pe.com.pacifico.helpia.common.ErrorCatalog;

/**
 * Callback hacia el Agente HelpIA (Stefanini).
 * En Azure, CALLBACK_HMAC_SECRET debe ser una referencia de Key Vault:
 * {@code @Microsoft.KeyVault(SecretUri=https://azkvhpiaeu2p01.vault.azure.net/secrets/...)}.
 */
public record CallbackSettings(String baseUrl, String hmacSecret) {

    public static CallbackSettings load(Env env) {
        String baseUrl = env.get("CALLBACK_BASE_URL");
        String secret = env.get("CALLBACK_HMAC_SECRET");
        if (!baseUrl.startsWith("https://") && !(baseUrl.startsWith("http://localhost") && !env.isRunningInAzure())) {
            throw new ApiException(ErrorCatalog.CONFIGURATION_ERROR);
        }
        if (secret.length() < 32) {
            throw new ApiException(ErrorCatalog.CONFIGURATION_ERROR);
        }
        return new CallbackSettings(baseUrl.replaceAll("/+$", ""), secret);
    }
}
