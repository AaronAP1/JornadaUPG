package pe.com.pacifico.helpia.infrastructure.local;

import java.util.logging.Logger;
import pe.com.pacifico.helpia.application.CallbackSender;
import pe.com.pacifico.helpia.domain.OperationResult;

/** LOCAL_MODE: no envía el callback, solo lo registra. El resultado se consulta en GET /api/operaciones/{id}. */
public final class LocalCallbackSender implements CallbackSender {

    private static final Logger LOG = Logger.getLogger(LocalCallbackSender.class.getName());

    @Override
    public void send(OperationResult result) {
        LOG.info(() -> "[MODO LOCAL] Callback no enviado; estado=" + result.estado() + "; codigo=" + result.codigo()
                + "; correlation-id=" + result.correlationId());
    }
}
