package pe.com.pacifico.helpia.application;

import pe.com.pacifico.helpia.domain.OperationResult;

/**
 * Puerto hacia el Agente HelpIA (paso 10 del diagrama).
 * Implementaciones: CallbackClient (HTTP firmado con HMAC) y LocalCallbackSender (LOCAL_MODE, solo registra en el log).
 */
public interface CallbackSender {

    void send(OperationResult result);
}
