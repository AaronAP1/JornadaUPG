package pe.com.pacifico.helpia.infrastructure.local;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import pe.com.pacifico.helpia.application.RunbookGateway;
import pe.com.pacifico.helpia.common.Json;
import pe.com.pacifico.helpia.infrastructure.automation.AutomationException;

/**
 * "Automation" en memoria para LOCAL_MODE. El job queda Running durante LOCAL_JOB_SECONDS y luego Completed con
 * resultado OK. Con el usuario "rapido" termina en 1 s, para ver la respuesta 200 síncrona.
 * Los jobs viven en memoria: si el proceso se reinicia a mitad de una orquestación, esa operación termina FALLIDA.
 */
public final class LocalRunbookGateway implements RunbookGateway {

    private static final Logger LOG = Logger.getLogger(LocalRunbookGateway.class.getName());
    private static final Map<String, String> RESULT_CODES = Map.of(
            "DESBLOQUEO", "DESBLOQUEADO",
            "RESETEO", "RESETEADO",
            "ACTUALIZACION_CELULAR", "CELULAR_ACTUALIZADO");

    private record Job(Instant createdAt, Duration duration, String operacion, String correlationId) {
    }

    private final Map<String, Job> jobs = new ConcurrentHashMap<>();
    private final Clock clock;
    private final Duration defaultDuration;

    public LocalRunbookGateway(Clock clock, Duration defaultDuration) {
        this.clock = clock;
        this.defaultDuration = defaultDuration;
    }

    @Override
    public void createJob(String jobName, String runbookName, Map<String, String> parameters) {
        Duration duration = "rapido".equalsIgnoreCase(parameters.get("Usuario")) ? Duration.ofSeconds(1) : defaultDuration;
        Job created = new Job(clock.instant(), duration, parameters.get("Operacion"), parameters.get("CorrelationId"));
        if (jobs.putIfAbsent(jobName, created) == null) {
            LOG.info(() -> "[MODO LOCAL] Job simulado creado; runbook=" + runbookName + "; job=" + jobName
                    + "; duracion=" + duration.toSeconds() + "s; correlation-id=" + created.correlationId());
        }
    }

    @Override
    public String getJobStatus(String jobName) {
        Job job = find(jobName);
        Duration elapsed = Duration.between(job.createdAt(), clock.instant());
        return elapsed.compareTo(job.duration()) < 0 ? "Running" : "Completed";
    }

    @Override
    public String getJobOutput(String jobName) {
        Job job = find(jobName);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("resultado", "OK");
        result.put("codigo", RESULT_CODES.getOrDefault(job.operacion(), "OK"));
        result.put("mensaje", "Operación simulada en modo local");
        result.put("correlationId", job.correlationId());
        return "Ejecución simulada (LOCAL_MODE)\n" + Json.write(result);
    }

    private Job find(String jobName) {
        Job job = jobs.get(jobName);
        if (job == null) {
            throw new AutomationException("Job inexistente en modo local: " + jobName);
        }
        return job;
    }
}
