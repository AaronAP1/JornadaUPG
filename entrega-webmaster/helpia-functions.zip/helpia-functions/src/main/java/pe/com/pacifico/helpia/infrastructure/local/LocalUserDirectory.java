package pe.com.pacifico.helpia.infrastructure.local;

import java.util.List;
import java.util.Locale;
import java.util.Optional;
import pe.com.pacifico.helpia.application.UserDirectory;
import pe.com.pacifico.helpia.domain.DirectoryUser;

/**
 * Directorio en memoria para LOCAL_MODE: cualquier usuario existe, es nominal y está habilitado,
 * salvo los que empiezan con "noexiste" (para probar el caso de usuario inexistente).
 */
public final class LocalUserDirectory implements UserDirectory {

    static final String LOCAL_DOMAIN = "pacificoseguros.local";
    static final String UPN_SUFFIX = "@pacifico.com.pe";

    @Override
    public Optional<DirectoryUser> getByUserPrincipalName(String email, String correlationId) {
        return exists(email) ? Optional.of(fromEmail(email)) : Optional.empty();
    }

    @Override
    public List<DirectoryUser> searchByEmail(String email, String correlationId) {
        return exists(email) ? List.of(fromEmail(email)) : List.of();
    }

    @Override
    public List<DirectoryUser> searchBySamAccountName(String samAccountName, String correlationId) {
        return exists(samAccountName) ? List.of(fromEmail(samAccountName + UPN_SUFFIX)) : List.of();
    }

    private static boolean exists(String value) {
        return !value.toLowerCase(Locale.ROOT).startsWith("noexiste");
    }

    private static DirectoryUser fromEmail(String email) {
        String localPart = email.substring(0, email.indexOf('@'));
        String sam = localPart.length() > 20 ? localPart.substring(0, 20) : localPart;
        return new DirectoryUser("local-" + sam, email, email, sam, LOCAL_DOMAIN, true, true);
    }
}
