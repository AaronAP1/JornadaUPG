package pe.com.pacifico.helpia.function;

import java.net.http.HttpClient;
import java.time.Clock;
import java.time.Duration;
import java.util.logging.Logger;
import pe.com.pacifico.helpia.application.AccountResolver;
import pe.com.pacifico.helpia.application.CallbackSender;
import pe.com.pacifico.helpia.application.DefaultAccountScopePolicy;
import pe.com.pacifico.helpia.application.EmailValidator;
import pe.com.pacifico.helpia.application.OperationRequestParser;
import pe.com.pacifico.helpia.application.RateLimitService;
import pe.com.pacifico.helpia.application.RunbookGateway;
import pe.com.pacifico.helpia.application.UserDirectory;
import pe.com.pacifico.helpia.application.UserLookupService;
import pe.com.pacifico.helpia.auth.JwtValidator;
import pe.com.pacifico.helpia.common.Env;
import pe.com.pacifico.helpia.config.AutomationSettings;
import pe.com.pacifico.helpia.config.CallbackSettings;
import pe.com.pacifico.helpia.config.EmailDomainSettings;
import pe.com.pacifico.helpia.config.JwtSettings;
import pe.com.pacifico.helpia.config.RateLimitSettings;
import pe.com.pacifico.helpia.config.SyncWaitSettings;
import pe.com.pacifico.helpia.domain.OrchestrationTimings;
import pe.com.pacifico.helpia.infrastructure.automation.AutomationClient;
import pe.com.pacifico.helpia.infrastructure.callback.CallbackClient;
import pe.com.pacifico.helpia.infrastructure.graph.GraphUserDirectory;
import pe.com.pacifico.helpia.infrastructure.identity.AzureTokenProvider;
import pe.com.pacifico.helpia.infrastructure.local.LocalCallbackSender;
import pe.com.pacifico.helpia.infrastructure.local.LocalMode;
import pe.com.pacifico.helpia.infrastructure.local.LocalRunbookGateway;
import pe.com.pacifico.helpia.infrastructure.local.LocalUserDirectory;
import pe.com.pacifico.helpia.infrastructure.storage.TableRateLimitStore;

/**
 * Composición de dependencias (sin Spring, para no penalizar el arranque en frío).
 * Las dependencias son únicas por proceso y se construyen la primera vez que se necesitan:
 * así health y users/exists funcionan aunque Automation o el callback aún no estén configurados.
 *
 * Con LOCAL_MODE=true (solo fuera de Azure), Graph, Automation y el callback se reemplazan por
 * implementaciones en memoria para probar el core: endpoints + Durable + Task hub.
 */
public final class Dependencies {

    static final String GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0";
    static final String ARM_BASE_URL = "https://management.azure.com";

    private static final Logger LOG = Logger.getLogger(Dependencies.class.getName());
    private static final Dependencies INSTANCE = new Dependencies(Env.system(), Clock.systemUTC());

    private final Env env;
    private final Clock clock;
    private final boolean localMode;
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(3))
            .followRedirects(HttpClient.Redirect.NEVER)
            .build();

    private final Lazy<JwtValidator> jwtValidator;
    private final Lazy<AzureTokenProvider> tokens;
    private final Lazy<UserDirectory> directory;
    private final Lazy<EmailDomainSettings> emailDomains;
    private final Lazy<EmailValidator> emailValidator;
    private final Lazy<UserLookupService> userLookup;
    private final Lazy<AccountResolver> accountResolver;
    private final Lazy<RateLimitService> rateLimitService;
    private final Lazy<AutomationSettings> automationSettings;
    private final Lazy<RunbookGateway> runbookGateway;
    private final Lazy<CallbackSender> callbackSender;
    private final OperationRequestParser operationRequestParser = new OperationRequestParser();

    Dependencies(Env env, Clock clock) {
        this.env = env;
        this.clock = clock;
        this.localMode = LocalMode.isEnabled(env);
        if (localMode) {
            LOG.warning("LOCAL_MODE activo: Graph, Automation y callback simulados en memoria. No usar fuera de local.");
        }

        this.jwtValidator = new Lazy<>(() -> JwtValidator.forEntraId(JwtSettings.load(env)));
        this.tokens = new Lazy<>(() -> AzureTokenProvider.fromEnvironment(env));
        this.directory = new Lazy<>(() -> localMode
                ? new LocalUserDirectory()
                : new GraphUserDirectory(http, tokens.get(), GRAPH_BASE_URL));
        this.emailDomains = new Lazy<>(() -> EmailDomainSettings.load(env));
        this.emailValidator = new Lazy<>(() -> new EmailValidator(emailDomains.get().allowedDomains()));
        this.userLookup = new Lazy<>(() -> new UserLookupService(directory.get()));
        this.accountResolver = new Lazy<>(() -> new AccountResolver(
                directory.get(), new DefaultAccountScopePolicy(emailDomains.get().allowedDomains())));
        this.rateLimitService = new Lazy<>(() -> {
            RateLimitSettings settings = RateLimitSettings.load(env);
            TableRateLimitStore store = settings.enabled()
                    ? TableRateLimitStore.create(settings, settings.connectionString().isEmpty() ? tokens.get().credential() : null)
                    : null;
            return new RateLimitService(settings, store, clock);
        });
        this.automationSettings = new Lazy<>(() -> localMode ? AutomationSettings.local() : AutomationSettings.load(env));
        this.runbookGateway = new Lazy<>(() -> localMode
                ? new LocalRunbookGateway(clock, Duration.ofSeconds(env.getInt("LOCAL_JOB_SECONDS", 10)))
                : new AutomationClient(http, tokens.get(), automationSettings.get(), ARM_BASE_URL));
        this.callbackSender = new Lazy<>(() -> localMode
                ? new LocalCallbackSender()
                : new CallbackClient(http, CallbackSettings.load(env), clock));
    }

    public static Dependencies get() {
        return INSTANCE;
    }

    public Clock clock() {
        return clock;
    }

    public JwtValidator jwtValidator() {
        return jwtValidator.get();
    }

    public EmailValidator emailValidator() {
        return emailValidator.get();
    }

    public UserLookupService userLookup() {
        return userLookup.get();
    }

    public OperationRequestParser operationRequestParser() {
        return operationRequestParser;
    }

    public AccountResolver accountResolver() {
        return accountResolver.get();
    }

    public RateLimitService rateLimitService() {
        return rateLimitService.get();
    }

    public AutomationSettings automationSettings() {
        return automationSettings.get();
    }

    public RunbookGateway runbookGateway() {
        return runbookGateway.get();
    }

    public CallbackSender callbackSender() {
        return callbackSender.get();
    }

    public OrchestrationTimings orchestrationTimings() {
        return OrchestrationTimings.load(env);
    }

    public SyncWaitSettings syncWaitSettings() {
        return SyncWaitSettings.load(env);
    }
}
