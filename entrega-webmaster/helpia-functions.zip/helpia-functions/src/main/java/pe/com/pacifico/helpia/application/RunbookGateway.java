package pe.com.pacifico.helpia.application;

import java.util.Map;

/**
 * Puerto hacia la ejecución de runbooks.
 * Implementaciones: AutomationClient (Azure Automation real) y LocalRunbookGateway (LOCAL_MODE).
 */
public interface RunbookGateway {

    /** Crea el job. Idempotente: el mismo nombre no ejecuta dos veces. */
    void createJob(String jobName, String runbookName, Map<String, String> parameters);

    /** Estado del job con la nomenclatura de Automation (New, Running, Completed, Failed...). */
    String getJobStatus(String jobName);

    /** Salida del job (la última línea JSON es el resultado). */
    String getJobOutput(String jobName);
}
