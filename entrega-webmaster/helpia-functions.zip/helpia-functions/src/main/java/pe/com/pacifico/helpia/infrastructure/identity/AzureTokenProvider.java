package pe.com.pacifico.helpia.infrastructure.identity;

import com.azure.core.credential.AccessToken;
import com.azure.core.credential.TokenCredential;
import com.azure.core.credential.TokenRequestContext;
import com.azure.core.exception.ClientAuthenticationException;
import com.azure.identity.AzureCliCredentialBuilder;
import com.azure.identity.ManagedIdentityCredentialBuilder;
import java.util.regex.Pattern;
import pe.com.pacifico.helpia.common.ApiException;
import pe.com.pacifico.helpia.common.Env;
import pe.com.pacifico.helpia.common.ErrorCatalog;

/**
 * Equivale a _build_graph_credential() de Python.
 * En Azure: Managed Identity (user-assigned si AZURE_CLIENT_ID está definido).
 * En local: sesión de Azure CLI del desarrollador (az login) contra AZURE_TENANT_ID.
 * La librería cachea los tokens; no hace falta cachearlos aquí.
 */
public final class AzureTokenProvider implements AccessTokenProvider {

    private static final Pattern GUID = Pattern.compile(
            "^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", Pattern.CASE_INSENSITIVE);

    private final TokenCredential credential;

    public AzureTokenProvider(TokenCredential credential) {
        this.credential = credential;
    }

    public static AzureTokenProvider fromEnvironment(Env env) {
        if (env.isRunningInAzure()) {
            ManagedIdentityCredentialBuilder builder = new ManagedIdentityCredentialBuilder();
            String clientId = env.get("AZURE_CLIENT_ID");
            if (!clientId.isEmpty()) {
                builder.clientId(clientId);
            }
            return new AzureTokenProvider(builder.build());
        }
        String tenantId = env.get("AZURE_TENANT_ID").toLowerCase();
        if (!GUID.matcher(tenantId).matches()) {
            throw new ApiException(ErrorCatalog.GRAPH_CONFIGURATION_ERROR);
        }
        return new AzureTokenProvider(new AzureCliCredentialBuilder().tenantId(tenantId).build());
    }

    public TokenCredential credential() {
        return credential;
    }

    @Override
    public String getToken(String scope) {
        try {
            AccessToken token = credential.getTokenSync(new TokenRequestContext().addScopes(scope));
            if (token == null || token.getToken() == null) {
                throw new TokenUnavailableException("Token vacío para " + scope, null);
            }
            return token.getToken();
        } catch (ClientAuthenticationException | IllegalArgumentException e) {
            // CredentialUnavailableException es subclase de ClientAuthenticationException.
            throw new TokenUnavailableException("No fue posible obtener token para " + scope, e);
        }
    }
}
