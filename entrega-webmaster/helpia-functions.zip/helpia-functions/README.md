# helpia-functions

Function App en Java de **HelpIA** (autoservicio de identidad para Pacífico).
Reemplaza al servicio Python `HPIA_HEALTH_UserExist` y agrega la orquestación con **Durable Functions**
para desbloqueo, reseteo y actualización de celular.

- Mapeo con la arquitectura y con el código Python: [docs/MAPEO-ARQUITECTURA.md](docs/MAPEO-ARQUITECTURA.md)
- Despliegue, permisos y reemplazo sin corte: [docs/DESPLIEGUE.md](docs/DESPLIEGUE.md)
- Contrato con los runbooks: [docs/CONTRATO-RUNBOOKS.md](docs/CONTRATO-RUNBOOKS.md)
- Contrato de la API (API First): [openapi/helpia-api.yaml](openapi/helpia-api.yaml)
- Pruebas locales del core con Docker (Function App + Azurite): [docs/PRUEBAS-LOCALES.md](docs/PRUEBAS-LOCALES.md)

## Flujo

```
Bot HelpIA ──► APIM (validate-jwt) ──► Function App
                                        ├─ Health / validar-existencia  → Microsoft Graph (síncrono)
                                        └─ desbloquear / resetear / celular
                                             starter ─► AccountOperationOrchestrator (Task hub)
                                                         ├─ StartRunbookActivity      → Automation → Hybrid Worker → AD
                                                         ├─ timers + GetRunbookJobStatusActivity
                                                         └─ SendCallbackActivity      → POST /helpia/callback/{correlationId}
```

Respuesta: si el job termina durante la espera corta (≈3 × 2 s) → **200** con el resultado;
si no → **202** y el resultado llega por **callback** firmado (HMAC). Respaldo: `GET /api/operaciones/{correlationId}`.

## Estructura

```
src/main/java/pe/com/pacifico/helpia/
├── function/
│   ├── http/            Endpoints HTTP (lo que ve APIM) y starter de Durable
│   ├── orchestration/   Orquestador, política de polling y reintentos
│   ├── activity/        Activities: crear job, consultar job, enviar callback
│   ├── Dependencies     Composición de dependencias (sin Spring)
│   └── Lazy
├── application/         Lógica de negocio pura (testeable sin Azure)
├── domain/              Modelos (comandos, resultados, estados)
├── auth/                Validación JWT de Entra ID
├── infrastructure/      Graph, Automation, callback, Table Storage, Managed Identity
├── config/              Lectura y validación de app settings
└── common/              Errores, correlationId, JSON, headers
```

## Requisitos locales

- JDK 17, Gradle 8.12.1 (`gradle wrapper --gradle-version 8.12.1` para generar el wrapper)
- Azure Functions Core Tools v4
- Azurite (storage local para el Task hub y los límites)
- `az login` en el tenant de Dev (Graph y Automation se llaman con tu identidad)

## Ejecutar

```bash
cp local.settings.example.json local.settings.json   # completar valores de Dev
azurite --silent &
gradle build                 # compila y ejecuta tests
gradle azureFunctionsRun     # levanta las funciones en http://localhost:7071/api
```

Para pruebas locales sin token real: `"JWT_LOCAL_BYPASS": "true"` en `local.settings.json`.
La app se niega a arrancar con esa opción en Azure (503 `INSECURE_CONFIGURATION_BLOCKED`).

## Reglas para no romper Durable

1. No renombrar `AccountOperationOrchestrator` ni las activities una vez desplegados.
2. El orquestador debe ser determinista: sin `Instant.now()`, `UUID.randomUUID()`, I/O ni variables de entorno.
3. No capturar `RuntimeException` genérica dentro del orquestador.
4. Cambios incompatibles: desplegar sin instancias en curso o crear una versión `V2`.
