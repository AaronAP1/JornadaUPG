# Compila, empaqueta y levanta Function App + Azurite.
$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)

gradle test
gradle azureFunctionsPackage
docker compose up --build -d

Write-Host "Esperando a que la Function App responda..."
for ($i = 0; $i -lt 30; $i++) {
    try {
        $r = Invoke-RestMethod -Uri http://localhost:7071/api/health -Headers @{ Authorization = 'Bearer local'; 'x-functions-key' = 'clave-local' }
        Write-Host "Function App lista:" ($r | ConvertTo-Json -Compress)
        break
    } catch { Start-Sleep -Seconds 3 }
}
Write-Host "Logs:     docker compose logs -f functions"
Write-Host "Pruebas:  docker/pruebas.http"
Write-Host "Task hub: Azure Storage Explorer -> Emulator (puertos 10000-10002), tablas HelpiaLocalInstances / HelpiaLocalHistory"
