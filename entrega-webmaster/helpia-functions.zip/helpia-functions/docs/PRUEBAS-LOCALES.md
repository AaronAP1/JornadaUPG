# Pruebas locales del core: endpoints + Durable Functions + Task hub

Levanta solo dos contenedores:

| Contenedor | Rol | Puerto |
|---|---|---|
| `functions` | La Function App real (imagen oficial `azure-functions/java:4-java17`) | 7071 |
| `azurite` | Storage local: Task hub de Durable, function keys y tabla de límites | 10000-10002 |

No necesita Azure Functions Core Tools (el runtime corre en el contenedor) ni acceso a Azure.

## Qué es real y qué está en memoria

Con `LOCAL_MODE=true` la app reemplaza las tres dependencias externas por implementaciones en memoria
(`infrastructure/local/`), para aislar el core:

| Dependencia | En LOCAL_MODE |
|---|---|
| Microsoft Graph | `LocalUserDirectory`: todo usuario existe, es nominal y está habilitado; los que empiezan con `noexiste` no existen |
| Azure Automation | `LocalRunbookGateway`: el job queda Running `LOCAL_JOB_SECONDS` (10 s) y termina OK; el usuario `rapido` termina en 1 s |
| Callback al bot | `LocalCallbackSender`: no envía nada, solo lo registra en el log |

Todo lo demás es el código real: endpoints, validaciones, JWT (en modo bypass), starter con espera corta,
orquestador, timers, activities, reintentos, eventos externos, idempotencia, límites y el Task hub en Azurite.

`LOCAL_MODE` se ignora si la app corre en Azure (`WEBSITE_SITE_NAME` o `WEBSITE_INSTANCE_ID`).

## Levantar

```powershell
gradle test
gradle azureFunctionsPackage
docker compose up --build
```

O todo junto: `./docker/levantar.ps1`. Luego ejecutar `docker/pruebas.http` desde IntelliJ.

Después de cambiar código: `gradle azureFunctionsPackage` y `docker compose up --build functions`.

## Ver el Task hub

Con Azure Storage Explorer → "Attach to a local emulator" (puertos por defecto):

- Tablas `HelpiaLocalInstances` (una fila por orquestación, con estado y custom status) y `HelpiaLocalHistory`
  (cada paso: inicio, activities, timers, eventos `ModoEntrega`, finalización).
- Colas `helpialocal-control-00..03` y `helpialocal-workitems` (mensajes en tránsito).
- Contenedor `helpialocal-leases`.

También: `docker compose logs -f functions` muestra el job simulado, el modo de entrega y el callback no enviado.

## Si algo falla

- **401 en todo:** falta `x-functions-key: clave-local` (definida en `docker/secrets/host.json`).
- **503 `INSECURE_CONFIGURATION_BLOCKED`:** el contenedor tiene variables `WEBSITE_*`; revisar `docker compose config`.
- **No baja imágenes o el extension bundle:** proxy corporativo (Docker Desktop → Settings → Resources → Proxies).
- **Reiniciar de cero:** `docker compose down` (borra el Task hub y los contadores de límites).
